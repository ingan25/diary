# SnakeGame in Java

### Build the project in NetBeans and start playing...

![Imgur](https://i.imgur.com/hqneAnP.gif)
